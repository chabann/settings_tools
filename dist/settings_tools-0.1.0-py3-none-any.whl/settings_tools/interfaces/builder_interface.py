class BuilderInterface:
    def __init__(self) -> None:
        pass

    def build():
        pass