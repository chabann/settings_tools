# Settings Tools

Графическая оболочка для запуска собственных расчетных проектов, позволяющая создавать и изменять профили с параметрами

To run application: poetry run python settings_tools/app.py

To run designer: pyqt6-tools designer